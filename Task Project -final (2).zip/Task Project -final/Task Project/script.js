document.addEventListener("DOMContentLoaded", function () {
    console.log("Task Tracker JS Loaded!");

    // Navbar Toggle (For Mobile)
    const navToggle = document.querySelector(".navbar-toggler");
    const navMenu = document.querySelector(".navbar-collapse");
    if (navToggle) {
        navToggle.addEventListener("click", function () {
            navMenu.classList.toggle("show");
        });
    }

    // Theme Toggle (Dark/Light Mode)
    const themeToggle = document.getElementById("theme-toggle");
    if (themeToggle) {
        themeToggle.addEventListener("click", function () {
            document.body.classList.toggle("dark-theme");
            if (document.body.classList.contains("dark-theme")) {
                localStorage.setItem("theme", "dark");
            } else {
                localStorage.setItem("theme", "light");
            }
        });

        // Load theme preference
        if (localStorage.getItem("theme") === "dark") {
            document.body.classList.add("dark-theme");
        }
    }

    // Form Validation (Example for Login or Register Forms)
    const forms = document.querySelectorAll(".needs-validation");
    forms.forEach(form => {
        form.addEventListener("submit", function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add("was-validated");
        });
    });
});
